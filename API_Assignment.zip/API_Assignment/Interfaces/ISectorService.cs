﻿using System;
using dotnet_training_api.Models;
namespace dotnet_training_api.Interfaces
{
	public interface ISectorService
	{
		public List<SectorModel> GetSectors();
	}
}

