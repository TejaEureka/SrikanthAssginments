﻿using System;
namespace dotnet_training_api.Models
{
	public class StockModel
	{
		public string TickerSymbol { get; set; }
		public string TickerName { get; set; }


    }
}

