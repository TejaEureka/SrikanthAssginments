﻿using System;
using dotnet_training_api.Models;
using dotnet_training_api.Providers;
using dotnet_training_api.Interfaces;
namespace dotnet_training_api.Services
{
	public class StocksService : IStocksService
	{
		public IStocksProvider provider;
		public StocksService(IStocksProvider stocksProvider)
		{
			provider = stocksProvider;
		}

		public List<StockModel> GetStocks()
		{
			return provider.GetStocks();
		}
	}
}

