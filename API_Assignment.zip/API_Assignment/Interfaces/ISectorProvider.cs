﻿using System;
using dotnet_training_api.Models;
namespace dotnet_training_api.Interfaces
{
	public interface ISectorProvider
	{
		public List<SectorModel> GetSectors();
	}
}

