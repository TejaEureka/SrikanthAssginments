﻿using System;
namespace dotnet_training_api.Models
{
	public class SectorModel
	{
		public string SectorName { get; set; }
		public int SectorId { get; set; }
	}
}

