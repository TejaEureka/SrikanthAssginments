﻿using System;
using dotnet_training_api.Interfaces;
using dotnet_training_api.Models;

namespace dotnet_training_api.Services
{
	public class SectorService : ISectorService
	{
        public ISectorProvider provider;
        public SectorService(ISectorProvider sectorprovider)
		{
            provider = sectorprovider;
		}
        public List<SectorModel> GetSectors()
        {
            return provider.GetSectors();
        }
    }
}

