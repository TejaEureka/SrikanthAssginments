﻿using System;
using dotnet_training_api.Models;
namespace dotnet_training_api.Interfaces
{
	public interface IStocksProvider
	{
		public List<StockModel> GetStocks();


    }
}

