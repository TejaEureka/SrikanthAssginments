﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using dotnet_training_api.Models;
using dotnet_training_api.Services;
using dotnet_training_api.Interfaces;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace dotnet_training_api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StocksController : Controller
    {
        IStocksService stocksService;
        public StocksController(IStocksService service)
        {
            stocksService = service;
        }
        [HttpGet(Name = "GetStocks")]
        public List<StockModel> Get()
        {
            return stocksService.GetStocks();
        }
    }
}

